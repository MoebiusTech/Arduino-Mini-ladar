# MiniRadar

拿着手机不知所措的同学，请打包下载，推荐使用电脑打包下载后再看。手机无法在线浏览。
下载是按绿色的 Clone or Download 按钮下载zip的打包文件。 不会用的可以看一下Github使用教程： https://www.ixigua.com/i6846441137809392131/

还是不会用的可以到百度下载程序资料大全包： http://dwz.date/bzg3    提取码: px9s （最后更新日期2020.6）

推荐直接使用Arduino.cc官网的web版编译器 
部分内容可能翻墙后更方便，推荐一个翻墙工具， https://github.com/bannedbook/fanqiang/wiki

请勿使用旺旺咨询任何关于程序调试、翻墙工具使用的任何问题。我们只能保证程序可以运行，关于程序的任何问题，请自行解决。如果没有调试运行Arduino程序的基础知识，请谨慎购买。

